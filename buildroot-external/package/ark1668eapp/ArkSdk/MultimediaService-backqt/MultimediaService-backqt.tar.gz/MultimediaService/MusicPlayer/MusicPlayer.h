#ifndef MUSICPLAYER_H
#define MUSICPLAYER_H

#include "DeviceWatcher/DeviceWatcher.h"
#include <QObject>
#include <QImage>
#include <QScopedPointer>

class MusicPlayerPrivate;
class MusicPlayer : public QObject
{
    Q_OBJECT
#ifdef g_MusicPlayer
#undef g_MusicPlayer
#endif
#define g_MusicPlayer (MusicPlayer::instance())
public:
    inline static MusicPlayer* instance() {
        static MusicPlayer* musicPlayer(new MusicPlayer(qApp));
        return musicPlayer;
    }
    void musicPlayerRequestFileNames(const int type);
    void musicPlayerSetPlayModeToggle();
    void musicPlayerSetPlayMode(const int mode);
    void musicPlayerSetPlayStatusToggle();
    void musicPlayerSetPlayStatus(const int status);
    void musicPlayerPlayListViewIndex(const int type, const int index, const int millesimal);
    void musicPlayerPlayPreviousListViewIndex();
    void musicPlayerPlayNextListViewIndex();
    void musicPlayerSeekToMillesimal(const int millesimal);
    void musicPlayerExit();
    void playMusicIndex(const DeviceWatcherType type, const int index, const int millesimal);
signals:
    void onMusicPlayerPlayMode(const int mode);
    void onMusicPlayerPlayStatus(const int type, const int status);
    void onMusicPlayerElapsedInformation(const int elapsedTime,
                                         const int elapsedMillesimal);
    void onMusicPlayerID3TagChange(const int type,
                                   const int index,
                                   const QString& fileName,
                                   const QString& title,
                                   const QString& artist,
                                   const QString& album,
                                   const int endTime);
    void onMusicPlayerFileNames(const  int type, const QString &xml);
    void onMusicPlayerFileArtist(const int type,QStringList artistList);
//    void onMusicPlayerFilePath(const int type, const QString& path);
protected slots:
    void onDeviceWatcherStatus(const int type, const int status);
    void onMusicFilePath(const QString &path, const int type);
private slots:
    void onTimeout();
private:
    explicit MusicPlayer(QObject* parent = NULL);
    ~MusicPlayer();
    MusicPlayerPrivate* const d_ptr;
    Q_DECLARE_PRIVATE(MusicPlayer)
};

#endif // MUSICPLAYER_H
